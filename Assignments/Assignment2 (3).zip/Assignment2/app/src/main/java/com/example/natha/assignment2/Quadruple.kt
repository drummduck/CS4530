package com.example.natha.assignment2

/**
 * Created by Natha on 10/10/2017.
 */
class Quadruple{

    var color: IntArray
    var width: Float
    var join: String
    var cap: String

    constructor(color: IntArray, width: Float, join: String, cap: String) {
        this.color = color
        this.width = width
        this.join = join
        this.cap = cap
    }
}